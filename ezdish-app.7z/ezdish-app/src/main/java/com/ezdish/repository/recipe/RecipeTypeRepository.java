package com.ezdish.repository.recipe;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ezdish.model.recipe.RecipeType;

public interface RecipeTypeRepository extends JpaRepository<RecipeType, String> {
	Optional<RecipeType> findRecipeTypeByCategory(String category);
}
