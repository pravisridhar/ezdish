package com.ezdish.repository.recipe;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ezdish.model.recipe.Recipe;

public interface RecipeRepository extends JpaRepository<Recipe, String> {
	List<Recipe> findRecipeByCode(String code);
	
	@Query(value = "SELECT * FROM recipe r WHERE " +
	        "EXISTS (SELECT 1 FROM recipe_type rt WHERE r.recipe_type = rt.code AND rt.category = :category)",
	        nativeQuery = true)
	List<Recipe> findAllRecipesByCategory(@Param("category") String category);
}
