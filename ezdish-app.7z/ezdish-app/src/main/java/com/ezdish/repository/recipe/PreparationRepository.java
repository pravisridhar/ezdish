package com.ezdish.repository.recipe;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ezdish.model.recipe.Preparation;
import com.ezdish.model.recipe.Recipe;

public interface PreparationRepository extends JpaRepository<Preparation, Long> {
	List<Preparation> findByRecipe(Recipe recipe, Sort sort);
}
