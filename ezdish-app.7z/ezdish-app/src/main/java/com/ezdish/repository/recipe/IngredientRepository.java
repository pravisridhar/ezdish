package com.ezdish.repository.recipe;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ezdish.model.recipe.Ingredient;
import com.ezdish.model.recipe.Recipe;

public interface IngredientRepository extends JpaRepository<Ingredient, Long> {
	List<Ingredient> findByRecipe(Recipe recipe, Sort sort);
}
