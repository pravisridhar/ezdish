package com.ezdish.model.recipe;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@Data
@Entity
@Table(name="preparation")
public class Preparation {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
	private Long id;
	
	@Column(name = "step")
	private Integer step;

	@Column(name = "detail")
	private String detail;
	
	@Column(name = "optional")
	private boolean optional;
	
	@Column(name = "tips")
	private String tips;
	
	@JsonBackReference
	@OneToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "recipe_code", nullable = true)
    private Recipe recipe;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}

	public Integer getStep() {
		return step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public boolean isOptional() {
		return optional;
	}

	public void setOptional(boolean optional) {
		this.optional = optional;
	}

	public String getTips() {
		return tips;
	}

	public void setTips(String tips) {
		this.tips = tips;
	}

	public Recipe getRecipe() {
		return recipe;
	}

	public void setRecipe(Recipe recipe) {
		this.recipe = recipe;
	}

	public Preparation() {}
	
	public Preparation(Integer step, String detail, boolean optional, String tips, Recipe recipe) {
		super();
		this.step = step;
		this.detail = detail;
		this.optional = optional;
		this.tips = tips;
		this.recipe = recipe;
	}
}
