package com.ezdish.controller.recipe;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ezdish.model.admin.User;
import com.ezdish.model.recipe.RecipeType;
import com.ezdish.repository.recipe.RecipeTypeRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/ezdish")
public class RecipeTypeController {
	@Autowired
	RecipeTypeRepository recipeTypeRepository;
	
	@GetMapping("/recipetypes")
	public ResponseEntity<List<RecipeType>> getAllRecipeTypes(@RequestParam(required = false) String recipeTypeCode) {
		try {
			List<RecipeType> recipeTypes = new ArrayList<RecipeType>();
			
			if (recipeTypeCode == null)
				recipeTypeRepository.findAll().forEach(recipeTypes::add);
			
			if (recipeTypes.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(recipeTypes, HttpStatus.OK);
	    } catch (Exception e) {
	    	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
		
	@GetMapping("/recipetypes/{category}")
	public ResponseEntity<RecipeType> findRecipeTypeByCategory(@PathVariable("category") String category) {
		Optional<RecipeType> recipeTypeData = recipeTypeRepository.findRecipeTypeByCategory(category);

		if (recipeTypeData.isPresent()) {
			return new ResponseEntity<>(recipeTypeData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
