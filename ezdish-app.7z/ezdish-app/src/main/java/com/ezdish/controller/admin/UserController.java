package com.ezdish.controller.admin;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ezdish.model.admin.User;
import com.ezdish.repository.admin.UserRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/ezdish")
public class UserController {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder bcryptEncoder;

	@GetMapping("/users")
	public ResponseEntity<List<User>> getAllUsers(@RequestParam(required = false) String userName) {
		try {
			List<User> users = new ArrayList<User>();
			
			if (userName == null)
				userRepository.findAll().forEach(users::add);
			else
				userRepository.findByUserName(userName).forEach(users::add);

			if (users.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(users, HttpStatus.OK);
	    } catch (Exception e) {
	    	return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}
	
	@GetMapping("/getuser/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") long id) {
			Optional<User> userData = userRepository.findById(id);

		if (userData.isPresent()) {
			return new ResponseEntity<>(userData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/createuser")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		try {
			User _user = userRepository
					.save(new User(
							user.getUserName(), 
							bcryptEncoder.encode(user.getPassword()),
							user.getFirstName(),
							user.getLastName(),
							user.getEmail(),
							user.getRegisterDate(),
							user.isActive(), 
							user.isAdmin(), 
							user.getToken()));
			return new ResponseEntity<>(_user, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PutMapping("/updateuser/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") long id, @RequestBody User user) {
		Optional<User> userData = userRepository.findById(id);

		if (userData.isPresent()) {
			User _user = userData.get();
			_user.setUserName(user.getUserName());
			_user.setPassword(bcryptEncoder.encode(user.getPassword()));
			_user.setFirstName(user.getFirstName());
			_user.setLastName(user.getLastName());
			_user.setEmail(user.getEmail());
			_user.setRegisterDate(user.getRegisterDate());
			_user.setAdmin(user.isAdmin());
			_user.setActive(user.isActive());
			
			return new ResponseEntity<>(userRepository.save(_user), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/updateuserdetails/{username}")
	public ResponseEntity<User> updateUserDetails(@PathVariable("username") String userName, @RequestBody User user) {
		List<User> userData = userRepository.findByUserName(userName);

		if (!userData.isEmpty()) {
			User _user = userData.get(0);
			if(user.getFirstName() != null)
				_user.setFirstName(user.getFirstName());
			if(user.getLastName() != null)
				_user.setLastName(user.getLastName());
			if(user.getEmail() != null)
				_user.setEmail(user.getEmail());
			
			return new ResponseEntity<>(userRepository.save(_user), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/deleteuser/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id") long id) {
		try {
			userRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}

	@PutMapping("/deleteuserdetails/{username}")
	public ResponseEntity<User> deleteUserDetails(@PathVariable("username") String userName, @RequestBody User user) {
		List<User> userData = userRepository.findByUserName(userName);

		try {
			User _user = new User();
			if (!userData.isEmpty()) {
				_user = userData.get(0);
			}
			userRepository.deleteById(_user.getId());
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@DeleteMapping("/deleteusers")
	public ResponseEntity<HttpStatus> deleteAllUsers() {
		try {
			userRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping("/activeusers")
	public ResponseEntity<List<User>> findActiveUsers() {
		try {
			List<User> users = userRepository.findByActive(true);

			if (users.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(users, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
}
