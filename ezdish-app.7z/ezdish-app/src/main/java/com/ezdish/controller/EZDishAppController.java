package com.ezdish.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EZDishAppController {

	@RequestMapping({ "/test-ezdish" })
	public String firstPage() {
		return "Hello EeZeDish";
	}

}