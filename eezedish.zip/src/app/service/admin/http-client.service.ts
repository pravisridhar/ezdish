import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class User {
  constructor(
    public userName : string,
    public password : string,
    public firstName : string,
    public lastName : string,
    public email : string,
    public registerDate : string,
    public active : boolean,
    public admin : boolean,
  ) {}
}

export class DashboardVariety {
  constructor(
    public varietyCaption : string,
    public varietyCount : number,
    public varietyStyle : DashboardVarietyStyle,
  ) {}
}

export class DashboardVarietyStyle {
  constructor(
    public styleTop : number,
    public styleLeft : number,
    public styleFont : FontStyle,
  ) {}
}

export class FontStyle {
  constructor(
    public fontSize : number,
    public fontColor : FontColor,
  ) {}
}

export class FontColor {
  constructor(
    public colorR : number,
    public colorG : number,
    public colorB : number,
  ) {}
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {

  constructor(private httpClient:HttpClient) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json; charset=utf-8',
      'Authorization': 'Bearer ' + sessionStorage.getItem('authtoken')
    })
  };

  public getAllUsers() {
    console.log("Get all users..........");
    return this.httpClient.get<User[]>('http://localhost:8080/ezdish/users', this.httpOptions);
  }

  public deleteUser(user) {
    console.log("Delete user..........");
    return this.httpClient.delete<User>("http://localhost:8080/ezdish/user" + "/"+ user.userName, this.httpOptions);
  }

  public createUser(user) {
    console.log("Create users..........");
    return this.httpClient.post<User>("http://localhost:8080/ezdish/createUser", user, this.httpOptions);
  }
}
