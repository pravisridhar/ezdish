import { RecipeType } from "../../models/RecipeType.model";
import { Recipe } from "../../models/Recipe.model";
import { Ingredient } from "../../models/Ingredient.model";
import { Preparation } from "../../models/Preparation.model";

export class RecipeService {
    private recipeTypes: RecipeType[] = [
        new RecipeType('ezt1', 'veg', 'Vegetarian', 'Many vegetarian dishes from various cousines. Explore your favourites dishes and learn how to prepare the recipes by yourself with simple tips and minimum available ingredients. Enjoy cooking.'),
        new RecipeType('ezt2', 'nonveg', 'Non Vegetarian', 'Delicious homemade non-vegetarian cousines. The taste vary depends on the type of ingredients, containers and also the way you prepare and serve. Learn the easy tips for making your tastes.'),
        new RecipeType('ezt3', 'tea', 'Tea', 'Variety of tea with different flavours. Many ingredients like ginger, cardamom, honey, jaggery etc addes the taste.'),
        new RecipeType('ezt4', 'coffee', 'Coffee', 'Variety of coffee with different coffee powders and also about the preparation of filtered coffee.'),
        new RecipeType('ezt5', 'juice', 'Juices', 'Collection of yummy fruit juice and its preparations. It requires less effort.'),
        new RecipeType('ezt6', 'salad', 'Salads', 'Preparation of vegetable salads and the garnishing techiniques.'),
        new RecipeType('ezt7', 'icecream', 'Ice Creams', 'Yummy ice creams and its preparations with various simple homely tips.'),
        new RecipeType('ezt8', 'pickle', 'Pickles', 'Delicious fruits, vegetables, fish, meat pickle preparation and how to preserve it for long time.'),
        new RecipeType('ezt9', 'snack', 'Snacks', 'Varieties of veg and non veg, soft, crispy, sweet, salty, spicy and tea time snacks.'),
        new RecipeType('ezt10', 'fry', 'Fries', 'Various veg and non veg fries used with main course and can be used as snacks. Also tips for more delicious.'),
        new RecipeType('ezt11', 'jam', 'Jams', 'Yummy fruit jams and the preparation with less number of available ingredients.'),
        new RecipeType('ezt12', 'pizza', 'Pizza', 'A yummy fast food and the home made preparation with available resources.'),
        new RecipeType('ezt13', 'bread', 'Breads', 'Delicious breads and its preparation and also how to make it as an ingredient for other recipes.'),
        new RecipeType('ezt14', 'cookie', 'Cookies', 'Yummy soft and crispy home made cookies. You can serve these at the tea time.'),
        new RecipeType('ezt15', 'sweet', 'Sweets', 'Celebration always accompanies with the sweets. Explore how you can make these quickly and simply at home.'),
        new RecipeType('ezt16', 'fruit', 'Fruits', 'Variety of dishes using fruits and its usage in making salads, icecreams, snacks, fries etc.'),
        new RecipeType('ezt17', 'spice', 'Spices', 'Essential ingredients to make your recipes to taste differently. The right quantity is always a challenge. Explore more to know the tips.'),
        new RecipeType('ezt18', 'candy', 'Candies', 'Candies are inevitable during celebration. Find your various candy preparations.'),
        new RecipeType('ezt19', 'seafood', 'Sea Foods', 'Delicious sea food recipes and check how to prepare these at home with minimal effort and simple way.'),
        new RecipeType('ezt20', 'soup', 'Soups', 'A good starter always makes a good feel for your dishes. Check how you can make home made soups easily.'),
        new RecipeType('ezt21', 'cake', 'Cakes', 'We cannot avoid cakes on your birthday. Try making home made cakes and enjoy with your get together.'),
        new RecipeType('ezt22', 'pastry', 'Pastries', 'A collection of yummy pastries. Check how to make pastries at home.'),
        new RecipeType('ezt23', 'rice', 'Rice', 'Variety of rice dishes with the blend of veg and nonveg ingredients.'),
        new RecipeType('ezt24', 'milk', 'Milk and Milk Products', 'Delicious energy giving food items from milk and milk products.')
      ];
    
    private ingredients: Ingredient[] = [
        new Ingredient('onion', 2, 'nos', ''),
        new Ingredient('tomato', 2, 'nos', '')
      ];

    private preparation: Preparation[] = [
        new Preparation(1, 'Details 1'),
        new Preparation(2, 'Details 2'),
        new Preparation(3, 'Details 3'),
        new Preparation(4, 'Details 4'),
        new Preparation(5, 'Details 5'),
        new Preparation(6, 'Details 6')
      ];

    private recipes: Recipe[] = [
        new Recipe('ez1', 'Mixed Veg Curry', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_1.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez2', 'Paneer Masala', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_2.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez3', 'Mushroom Masala', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_3.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez4', 'Gobi Manchurian', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_4.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez5', 'Chola Masala', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_5.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez6', 'Palak curry', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_6.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez7', 'Bindhi Fry', 'ezt10', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_7.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez8', 'Vegetarian Pulav', 'ezt23', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_8.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez9', 'Sambar', 'ezt1', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_9.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez10', 'Babycorn Masala Fry', 'ezt10','This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_10.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez11', 'Chicken Biriyani', 'ezt2', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_1.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez12', 'Butter Chicken', 'ezt2', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_2.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez13', 'Fruit salad', 'ezt13', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_3.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez14', 'Masala Tea', 'ezt3', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_4.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez15', 'Vegetable Biriyani', 'ezt23', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_5.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez16', 'Ghee Rice', 'ezt23', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_6.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez17', 'Paratha', 'ezt13', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_7.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez18', 'Lemon Rice', 'ezt23', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_8.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez19', 'Fish Fry', 'ezt19', 'This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_9.jpg', 'Praveen', this.ingredients, this.preparation, ''),
        new Recipe('ez20', 'Prawns Masala', 'ezt19','This Indian style mixed vegetable curry recipe is a family favorite and my mom’s recipe. It tastes delicious with phulkas, parathas or pooris.The best part of this mix vegetable curry recipe is that you can use spare veggies that are in your kitchen and make a one pot tasty mix veg gravy.', 'http://localhost:4200/assets/images/veggie/veggie_10.jpg', 'Praveen', this.ingredients, this.preparation, '')
      ];

    private selectedCategory: string;
    private selectedRecipeType: RecipeType;
    private selectedRecipe: Recipe;

    getAllRecipeTypes() {
      return this.recipeTypes.slice();
    }

    getAllRecipes() {
      let allCategoryRecipes: Recipe[] = [];
      this.recipes.slice().forEach( (recipe: Recipe) => {
        if(this.selectedRecipeType.code == recipe.category)
          allCategoryRecipes.push(recipe);
      });
      console.log(allCategoryRecipes);
      return allCategoryRecipes;
    }

    setSelectedRecipeCategory(category: string) {
      this.selectedCategory = category;
      this.recipeTypes.forEach( (recipeType: RecipeType) => {
        if(category == recipeType.category)
          this.selectedRecipeType = recipeType;
      });
    }

    getSelectedRecipeCategory() {
      return this.selectedCategory;
    }

    getSelectedRecipeType() {
      return this.selectedRecipeType;
    }

    setSelectedRecipe(recipe: Recipe) {
      this.selectedRecipe = recipe;
    }

    getRecipeByCode(code: string) {
      this.recipes.forEach( (recipe: Recipe) => {
        if(code == recipe.code)
          this.selectedRecipe = recipe;
      });
      return this.selectedRecipe;
    }
}