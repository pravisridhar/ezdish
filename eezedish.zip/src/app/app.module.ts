import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutModule } from './about/about.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { LayoutModule } from './layout/layout.module';
import { LoginModule } from './login/login.module';
import { RegisterModule } from './register/register.module';
import { AdminModule } from './admin/admin.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthenticationService } from './service/auth/authentication.service';
import { HttpAuthInterceptorService } from './service/auth/http-auth-interceptor.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { RecipesModule } from './modules/recipes/recipes.module';
import { RecipeService } from './service/recipe/recipe.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    AboutModule,
    LoginModule,
    AdminModule,
    RegisterModule,
    DashboardModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule,
    RecipesModule
  ],
  providers: [
    AuthenticationService,
    { provide:HTTP_INTERCEPTORS, useClass:HttpAuthInterceptorService, multi:true },
    RecipeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
