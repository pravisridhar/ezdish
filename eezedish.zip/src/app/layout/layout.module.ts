import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { PublicViewComponent } from './public-view/public-view.component';
import { PrivateViewComponent } from './private-view/private-view.component';
import { MenuComponent } from './menu/menu.component';
import { RouterModule } from '@angular/router';
import { AuthenticationService } from '../service/auth/authentication.service';



@NgModule({
  declarations: [HeaderComponent, FooterComponent, PublicViewComponent, PrivateViewComponent, MenuComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([])
  ],
  providers: [
    AuthenticationService
  ]
})
export class LayoutModule { }
