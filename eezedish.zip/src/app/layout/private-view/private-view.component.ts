import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-private-view',
  templateUrl: './private-view.component.html',
  styleUrls: ['./private-view.component.css']
})
export class PrivateViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
