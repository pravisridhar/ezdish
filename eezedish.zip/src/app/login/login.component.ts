import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/auth/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName: string;
  password: string;
  invalidLogin: boolean = false;
  
  constructor(private router: Router,
    private loginservice: AuthenticationService) { }

  ngOnInit(): void {
  }

  checkLogin() {
    this.loginservice.authenticate(this.userName, this.password).subscribe(
      data => {
        this.router.navigate(['dashboard'])
        this.invalidLogin = false
      },
      error => {
        this.invalidLogin = true
      }
    );
  }
}
