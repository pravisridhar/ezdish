import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicViewComponent } from '../layout/public-view/public-view.component';
import { LoginComponent } from './login.component';
import { FormsModule } from '@angular/forms';


const routes: Routes = [
  {
    path: 'login',
    component: PublicViewComponent,
    children: [
      { path: '', component: LoginComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes), FormsModule],
  exports: [RouterModule]
})
export class LoginRoutingModule { }
