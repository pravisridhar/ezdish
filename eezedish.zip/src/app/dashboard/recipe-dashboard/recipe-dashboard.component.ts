import { Component, OnInit } from '@angular/core';

import { RecipeType } from '../../models/RecipeType.model';
import { RecipeService } from '../../service/recipe/recipe.service';

@Component({
  selector: 'app-recipe-dashboard',
  templateUrl: './recipe-dashboard.component.html',
  styleUrls: ['./recipe-dashboard.component.css']
})
export class RecipeDashboardComponent implements OnInit {

  recipeTypes: RecipeType[];

  constructor(private recipeService: RecipeService) { }

  ngOnInit(): void {
    this.recipeTypes = this.recipeService.getAllRecipeTypes();
  }

}
