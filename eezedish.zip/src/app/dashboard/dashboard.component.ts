import { Component, OnInit } from '@angular/core';
import { DashboardVariety, DashboardVarietyStyle, FontStyle, FontColor } from '../service/admin/http-client.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  images = [1,2,3,4,5].map((n) => `http://localhost:4200/assets/images/slides/${n}.jpg`);
  recipes_types : string[] = [
    'veggie', 'nonveg', 'tea', 'coffee', 'juices', 'salads', 'icecream', 'pickles', 'shakes', 'fries', 
    'jam', 'pizza', 'bread', 'cookies', 'sweets', 'fruits', 'spices', 'candies', 'snacks', 'seafood'
  ]
  
  fontSize : string[] = [
    '150%', '200%', '250%', '300%', '350%', '400%', '450%', '500%'
  ];

  letterSpacing : string[] = [
    '1px', '2px', '5px', '10px', '0.1em', '0.2em', '0.5em', '1em'
  ];

  varieties : DashboardVariety[] = [];

  constructor() { }

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard() {
    for(let recipeType of this.recipes_types) {
      this.varieties.push(new DashboardVariety(recipeType, 101, 
        new DashboardVarietyStyle(this.getRandomNumber(75, 350), this.getRandomNumber(40, 75),
          new FontStyle(this.getRandomNumber(0, 7),
            new FontColor(this.getRandomNumber(0, 255), this.getRandomNumber(0, 255), this.getRandomNumber(0, 255))))));
    }
  }

  getRandomNumber(min : number, max : number){
    return Math.floor(Math. random() * (max - min + 1) + min);
  }

  fetchStyle(index : number) {
    return { 
          'top'  : this.varieties[index].varietyStyle.styleTop + 'px',
          'left' : this.varieties[index].varietyStyle.styleLeft + '%',
          'position' : 'absolute',
          'color' : 'rgb(' + this.varieties[index].varietyStyle.styleFont.fontColor.colorR + ','
            + this.varieties[index].varietyStyle.styleFont.fontColor.colorG + ','
            + this.varieties[index].varietyStyle.styleFont.fontColor.colorB + ')',
          'font-size' : this.fontSize[this.varieties[index].varietyStyle.styleFont.fontSize],
          'font-family' : '"Lucida Console", Courier, monospace',
          'text-shadow' : '0 1px 0 black',
          'z-index' : 5,
          'opacity' : 0.3,
        }
  }
}
