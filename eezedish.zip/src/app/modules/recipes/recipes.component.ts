import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { RecipeService } from 'src/app/service/recipe/recipe.service';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  recipeCategory: string;

  constructor(private route: ActivatedRoute, 
              private router: Router,
              private recipeService: RecipeService) { }

  ngOnInit(): void {
    // this.route.queryParams
    //   .subscribe(params => {        
    //     if(params && params.category) {
    //       console.log(1111);
    //       this.recipeCategory = params.category;
    //       this.recipeService.setSelectedRecipeCategory(this.recipeCategory);
    //     }
    //     else
    //       this.router.navigate(['/dashboard']);
    //   }
    // );
    this.route.params
      .subscribe(
        (params: Params) => {
          this.recipeCategory = params['category'];
          if(this.recipeCategory != '') {
            this.recipeService.setSelectedRecipeCategory(this.recipeCategory);
          }
          else {
            this.router.navigate(['/dashboard']);
          }
        }
      )
  }
}