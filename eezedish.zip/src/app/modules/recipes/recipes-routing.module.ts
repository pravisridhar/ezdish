import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicViewComponent } from 'src/app/layout/public-view/public-view.component';
import { RecipesComponent } from './recipes.component';
import { RecipeStartComponent } from './recipe-start/recipe-start.component';
import { RecipeDetailComponent } from './recipe-detail/recipe-detail.component';

const routes: Routes = [
  { path: 'recipes', component: PublicViewComponent, // The main path
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full'}, // As /recipes need a category, path redirect to the dashboard again.
      { path: ':category', component: RecipesComponent, // Opens /recipes/veg recipes
        children: [
          { path: '', component: RecipeStartComponent }, // Opens /recipes/veg default display
          { path: ':code', component: RecipeDetailComponent }, // Accessing /recipes/veg/ez001
        ],
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecipesRoutingModule { }
