import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Recipe } from './../../../models/Recipe.model';
import { Ingredient } from './../../../models/Ingredient.model';
import { RecipeService } from 'src/app/service/recipe/recipe.service';
import { RecipeType } from 'src/app/models/RecipeType.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {

  recipes: Recipe[] = [];
  category: string;
  activeRecipeType: RecipeType;
  
  constructor(private route: ActivatedRoute, private recipeService: RecipeService) {
  }

  ngOnInit(): void {
    this.activeRecipeType = this.recipeService.getSelectedRecipeType();
    this.recipes = this.recipeService.getAllRecipes();
    console.log('after in list....' + this.recipes);
  }
}
