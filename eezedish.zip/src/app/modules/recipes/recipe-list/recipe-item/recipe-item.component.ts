import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Recipe } from 'src/app/models/Recipe.model';
import { RecipeService } from 'src/app/service/recipe/recipe.service';

@Component({
  selector: 'app-recipe-item',
  templateUrl: './recipe-item.component.html',
  styleUrls: ['./recipe-item.component.css']
})
export class RecipeItemComponent implements OnInit {

  @Input() recipe: Recipe;
  @Input() recipeCode: string;

  constructor(private recipeService: RecipeService) { }

  ngOnInit(): void {
    console.log(this.recipe);
    console.log(this.recipeCode);
    this.recipeService.setSelectedRecipe(this.recipe);
  }
}
