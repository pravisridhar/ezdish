import { Ingredient } from "./Ingredient.model";
import { Preparation } from "./Preparation.model";

export class Recipe {
  code: string;
  name: string;
  description: string;
  category: string;
  image: string;
  author: string;
  ingredients: Ingredient[];
  preparation: Preparation[];
  video: string;

  constructor(code: string, 
              name: string, 
              category: string,
              description: string,
              image: string, 
              author: string,
              ingredients: Ingredient[], 
              preparation: Preparation[],
              video: string) {
    this.code = code;
    this.name = name;
    this.category = category;
    this.description = description;
    this.image = image;
    this.author = author;
    this.ingredients = ingredients;
    this.preparation = preparation;
    this.video = video;
  }
}