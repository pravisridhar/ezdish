export class Preparation {
    step: number;
    detail: string;

    constructor(step: number, detail: string) {
      this.step = step;
      this.detail = detail;
    }
}