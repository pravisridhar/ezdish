import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: '', // In url if there is only domain
    redirectTo: '/login', // then redirect to login page
    pathMatch: 'full'
  },
  { path: 'logout', loadChildren: () => import('./logout/logout.module').then(m => m.LogoutModule) }  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
