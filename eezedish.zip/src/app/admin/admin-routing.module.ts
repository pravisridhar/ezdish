import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './admin.component';
import { PublicViewComponent } from '../layout/public-view/public-view.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { AddUserComponent } from './user/add-user/add-user.component';
import { AuthGaurdService } from '../service/auth/auth-guard.service';


const routes: Routes = [
  {
    path: 'admin',
    component: PublicViewComponent,
    children: [
      { path: '', component: AdminComponent },
      { path: 'users', component: UserListComponent, canActivate:[AuthGaurdService] },
      { path: 'adduser', component: AddUserComponent, canActivate:[AuthGaurdService] }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
