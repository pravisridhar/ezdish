package com.ezdish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EZDishApplication {

	public static void main(String[] args) {
		SpringApplication.run(EZDishApplication.class, args);
	}
}