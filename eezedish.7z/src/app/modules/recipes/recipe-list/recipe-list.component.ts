import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { Recipe } from './../../../models/Recipe.model';
import { Ingredient } from './../../../models/Ingredient.model';
import { RecipeService } from 'src/app/service/recipe/recipe.service';
import { RecipeType } from 'src/app/models/RecipeType.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  recipes: Recipe[] = [];
  recipeCategory: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private recipeService: RecipeService) {
  }

  ngOnInit(): void {
    this.route.params
      .subscribe(
        (params: Params) => {
          this.recipeCategory = params['category'];
          if(this.recipeCategory != '') {
            this.recipeService.getAllRecipesByCategory(this.recipeCategory).subscribe(
              responseData => {
                this.recipes = responseData;
              }
            );
          }
          else {
            this.router.navigate(['/dashboard']);
          }
        }
      )
  }
}
