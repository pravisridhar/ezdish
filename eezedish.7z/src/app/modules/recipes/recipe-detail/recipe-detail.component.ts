import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

import { Recipe } from 'src/app/models/Recipe.model';
import { RecipeService } from 'src/app/service/recipe/recipe.service';
import { Ingredient } from 'src/app/models/Ingredient.model';
import { Preparation } from 'src/app/models/Preparation.model';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {

  recipe: Recipe = {  code : '',
                      name : '',
                      recipeType: '',
                      description : '',
                      image : '',
                      author : '',
                      ingredients : [],
                      preparations : [],
                      video : ''
                    };
  code: string;

  ingredients: Ingredient[] = [];
  preparations: Preparation[] = [];

  loadingInProgress: boolean = false;
  responseError = { status : '', message: ''};

  constructor(private route: ActivatedRoute,
    private recipeService: RecipeService,
    private router: Router) { }

  ngOnInit(): void {
    this.loadingInProgress = true;
    this.route.params.subscribe(
      (params: Params) => {
        this.code = params['code'];
        this.recipeService.getRecipeByCode(this.code).subscribe(
          responseData => {
            if(responseData != null && responseData.length == 1) {
              this.recipe = new Recipe(
                responseData[0].code,
                responseData[0].name,
                responseData[0].recipeType,
                responseData[0].description,
                responseData[0].image,
                responseData[0].author,
                responseData[0].ingredients,
                responseData[0].preparations,
                responseData[0].video
              );
            }
          },
          errorResponse => {
            this.responseError.status = errorResponse.error.error;
            this.responseError.message = errorResponse.message;
          }
        );
      }
    );
    this.loadingInProgress = false;
  }
}
