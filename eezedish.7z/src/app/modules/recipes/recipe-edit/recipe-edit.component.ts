import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

import { Recipe } from 'src/app/models/Recipe.model';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { RecipeService } from 'src/app/service/recipe/recipe.service';
import { RecipeType } from 'src/app/models/RecipeType.model';
import { UOM } from 'src/app/models/UOM.model';
import { Ingredient } from 'src/app/models/Ingredient.model';
import { Preparation } from 'src/app/models/Preparation.model';

import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-recipe-edit',
  templateUrl: './recipe-edit.component.html',
  styleUrls: ['./recipe-edit.component.css']
})
export class RecipeEditComponent implements OnInit {
  recipeEditForm: FormGroup;

  editMode: boolean = false;
  formHeading: string = 'Create Recipe';
  category: string;
  code: string;
  recipeName: string;
  recipeType: string;
  optional: string[] = ['Yes', 'No'];
  submitted = false;

  editRecipeType: RecipeType;
  editRecipe: Recipe;
  uoms: UOM[];
  allRecipeTypes: RecipeType[] = [];

  recipeIngredients = new FormArray([]);
  ingredientData = new FormGroup({
    'name': new FormControl(null, Validators.required),
    'quantity': new FormControl(null, Validators.required),
    'uom': new FormControl(null, Validators.required),
    'optional': new FormControl('No'),
    'tips': new FormControl(null)
  });

  recipePreparations = new FormArray([]);
  preparationData = new FormGroup({
    'step': new FormControl(this.recipePreparations.length + 1, Validators.required),
    'detail': new FormControl(null, Validators.required),
    'optional': new FormControl('No'),
    'tips': new FormControl(null)
  });

  constructor(private route: ActivatedRoute,
              private router: Router,
              private recipeService: RecipeService,
              private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.recipeIngredients.push(this.ingredientData);
    this.recipePreparations.push(this.preparationData);
    this.recipeEditForm = new FormGroup({
        'recipeData' : new FormGroup({
        'code': new FormControl(null),
        'name': new FormControl(null, Validators.required),
        'type': new FormControl(null, Validators.required),
        'description': new FormControl(null, Validators.required),
        'author': new FormControl(null, Validators.required),
        'ingredients': this.recipeIngredients,
        'preparations': this.recipePreparations,
        'image': new FormControl(null),
        'video': new FormControl(null)
      })
    });

    this.route.params.subscribe(
      (params: Params) => {
        this.code = params['code'];
        console.log(this.code);
        this.uoms = this.recipeService.getAllUnits();
        this.recipeService.getAllRecipeTypes().subscribe(
          responseData => {
            for(let index = 0; index < responseData.length; index++) {
              //console.log('frm response --> ' + responseData[index].code);
              this.allRecipeTypes.push(new RecipeType(
                responseData[index].code,
                responseData[index].category,
                responseData[index].description,
                responseData[index].detail
              ));
            }
            //console.log('response after setting --> ' + this.allRecipeTypes);
          }
        );

        if(typeof this.code === 'undefined') this.editMode = false;
        else this.editMode = true;

        if(this.editMode) {
          this.formHeading = 'Modify Recipe';
          //this.editRecipe = this.recipeService.getRecipeByCode(this.code);
          //this.editRecipeType = this.recipeService.getSelectedRecipeType();
          //this.recipeType = this.editRecipeType.code;
          //this.recipeType = this.code;

          this.recipeService.getRecipeByCode(this.code).subscribe(
            responseData => {
                this.editRecipe = new Recipe(
                  responseData[0].code,
                  responseData[0].name,
                  responseData[0].recipeType,
                  responseData[0].description,
                  responseData[0].image,
                  responseData[0].author,
                  responseData[0].ingredients,
                  responseData[0].preparations,
                  responseData[0].video
                );

                this.recipeEditForm.patchValue(
                  {
                    'recipeData' : {
                      'code': this.editRecipe.code,
                      'name': this.editRecipe.name,
                      'type': this.editRecipe.recipeType,
                      'description': this.editRecipe.description,
                      'author': this.editRecipe.author,
                      'image': this.editRecipe.image,
                      'video': this.editRecipe.video
                    }
                  }
                );

                this.patchIngreients();
                this.patchPreparations();
                console.log("recipe for edit... " + this.recipeEditForm.get("recipeData"));
            }
          );
        }
      }
    );
  }

  patchIngreients() {
    for(let index=0; index < this.editRecipe.ingredients.length-1; index++)
      this.addNewIngredient();

    const ingredientArray = this.recipeEditForm.get('recipeData.ingredients') as FormArray;
    for(let index=0; index < ingredientArray.length; index++) {
      let ingredient: Ingredient = this.editRecipe.ingredients[index];
      let option: number = ingredient.optional ? 0 : 1;
      ingredientArray['controls'][index].patchValue({
        'name': ingredient.name,
        'quantity'  : ingredient.quantity,
        'uom': ingredient.uom,
        'optional': this.optional[option],
        'tips': ingredient.tips
      });
    }
  }

  patchPreparations() {
    console.log('this.editRecipe.preparations.length -- ' + this.editRecipe.preparations.length);
    for(let index=0; index < this.editRecipe.preparations.length-1; index++)
      this.addNewStep();

    const preparationArray = this.recipeEditForm.get('recipeData.preparations') as FormArray;
    for(let index=0; index < preparationArray.length; index++) {
      let preparation: Preparation = this.editRecipe.preparations[index];
      let option: number = preparation.optional ? 0 : 1;
      preparationArray['controls'][index].patchValue({
        'step': preparation.step,
        'detail': preparation.detail,
        'optional': this.optional[option],
        'tips': preparation.tips
      });
    }
  }

  addNewIngredient() {
    (<FormArray>this.recipeEditForm.get('recipeData.ingredients')).push(
      new FormGroup({
        'name': new FormControl(null, Validators.required),
        'quantity': new FormControl(null, Validators.required),
        'uom': new FormControl(null, Validators.required),
        'optional': new FormControl('No'),
        'tips': new FormControl(null)
      })
    )
  }

  deleteIngredient(index: number) {
    console.log('ingredient to delete - ' + index);
    (<FormArray>this.recipeEditForm.get('recipeData.ingredients')).removeAt(index);
  }

  addNewStep() {
    let stepLength = (<FormArray>this.recipeEditForm.get('recipeData.preparations')).length;
    (<FormArray>this.recipeEditForm.get('recipeData.preparations')).push(
      new FormGroup({
        'step': new FormControl(stepLength + 1, Validators.required),
        'detail': new FormControl(null, Validators.required),
        'optional': new FormControl('No'),
        'tips': new FormControl(null)
      })
    )
  }

  deleteStep(index: number) {
    (<FormArray>this.recipeEditForm.get('recipeData.preparations')).removeAt(index);

    // Rearrange the step sequence
    const preparationArray = this.recipeEditForm.get('recipeData.preparations') as FormArray;
    for(let index=0; index < preparationArray.length; index++) {
      console.log(preparationArray['controls'][index]);
      preparationArray['controls'][index].patchValue({ 'step': index+ 1});
    }
  }

  upload(files: File[]){
    //pick from one of the 4 styles of file uploads below
    this.uploadAndProgress(files);
  }

  uploadAndProgress(files: File[]){
    console.log(files)
    var formData = new FormData();
    Array.from(files).forEach(f => formData.append('file',f))

    // this.http.post('https://file.io', formData, {reportProgress: true, observe: 'events'})
    //   .subscribe(event => {
    //     if (event.type === HttpEventType.UploadProgress) {
    //       this.percentDone = Math.round(100 * event.loaded / event.total);
    //     } else if (event instanceof HttpResponse) {
    //       this.uploadSuccess = true;
    //     }
    // });
  }

  onSubmit() {
    setTimeout(() => { this.spinner.show(); }, 50);
    this.submitted = true;
    let recipeFormData = this.recipeEditForm.get('recipeData').value;
    let saveRecipe : Recipe;
    let ingredients : Ingredient[] = [];
    let preparations : Preparation[] = [];

    for(let index=0 ; index < recipeFormData.ingredients.length; index++)
      ingredients.push(
        new Ingredient(
          recipeFormData.ingredients[index].name,
          recipeFormData.ingredients[index].quantity,
          recipeFormData.ingredients[index].uom,
          (recipeFormData.ingredients[index].optional === 'Yes') ? true : false,
          recipeFormData.ingredients[index].tips
          )
      );

    for(let index=0 ; index < recipeFormData.preparations.length; index++)
      preparations.push(
        new Preparation(
          recipeFormData.preparations[index].step,
          recipeFormData.preparations[index].detail,
          (recipeFormData.preparations[index].optional === 'Yes') ? true : false,
          recipeFormData.preparations[index].tips
          )
      );

    if(recipeFormData.image === null)
      recipeFormData.image = 'http://localhost:4200/assets/images/logo-new.jpg';

    saveRecipe = new Recipe(
      recipeFormData.code,
      recipeFormData.name,
      recipeFormData.type,
      recipeFormData.description,
      recipeFormData.image,
      recipeFormData.author,
      ingredients,
      preparations,
      recipeFormData.video,
    );

    this.recipeService.saveRecipe(saveRecipe).subscribe(
      saveResponse => {
        console.log(saveResponse);
        this.editRecipe = saveResponse[0];
        setTimeout(() => { this.spinner.hide(); }, 50);
        this.router.navigate(['../'], { relativeTo: this.route });
      },
      errorResponse => {
        console.log(errorResponse.error.error);
        setTimeout(() => { this.spinner.hide(); }, 50);
      }
    );
  }

  onCancel() {
    this.submitted = false;
    this.recipeEditForm.reset();
  }
}
