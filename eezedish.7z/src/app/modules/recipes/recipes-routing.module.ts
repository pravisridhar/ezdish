import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicViewComponent } from 'src/app/layout/public-view/public-view.component';
import { RecipesComponent } from './recipes.component';
import { RecipeStartComponent } from './recipe-start/recipe-start.component';
import { RecipeDetailComponent } from './recipe-detail/recipe-detail.component';
import { RecipeEditComponent } from './recipe-edit/recipe-edit.component';
import { AuthGuardService } from 'src/app/service/auth/auth-guard.service';

const routes: Routes = [
  { path: 'recipes', component: PublicViewComponent, // The main path
    canActivate: [AuthGuardService],
    children: [
      { path: '', redirectTo: '/dashboard', pathMatch: 'full'}, // As /recipes need a category, path redirect to the dashboard again.
      { path: ':category', component: RecipesComponent, // Opens /recipes/veg recipes
        children: [
          { path: '', component: RecipeStartComponent }, // Opens /recipes/veg default display
          { path: 'new', component: RecipeEditComponent }, // Adding new /recipes/veg
          { path: ':code', component: RecipeDetailComponent }, // Accessing /recipes/veg/ez1
          { path: ':code/edit', component: RecipeEditComponent }, // Editing /recipes/veg/ez1
        ],
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RecipesRoutingModule { }
