import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private httpClient:HttpClient) { }

  authenticate(username, password) {
    console.log('authentication starts....');
    let data = {'username': username, 'password': password}; 
    return this.httpClient.post<any>('http://localhost:8080/ezdish/authenticate', data).pipe(
     map(
       userData => {
        sessionStorage.setItem('username',username);
        sessionStorage.setItem('authtoken', userData.token);
        console.log('authentication successful....');
        return userData;
       }
     )
    ); 
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username');
    console.log(!(user === null));
    return !(user === null);
  }

  logOut() {
    console.log('logout starts....');
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('authtoken');
    console.log('logout successful....');
  }
}