import { RecipeType } from "../../models/RecipeType.model";
import { Recipe } from "../../models/Recipe.model";
import { Ingredient } from "../../models/Ingredient.model";
import { Preparation } from "../../models/Preparation.model";
import { UOM } from "../../models/UOM.model";
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class RecipeService {
    private uoms: UOM[] = [
      new UOM('kg','Kilogram', 'Used for heavy ingredients.'),
      new UOM('g','Gram', 'Used for lighter ingredients.'),
      new UOM('l','Litre', 'Used for more quantity of liquid ingredients.'),
      new UOM('ml','Millilitre', 'Used for less quantity of liquid ingredients.'),
      new UOM('nos','Number', 'Used for piece count of ingredients.'),
      new UOM('pinch','Pinch', 'Used for better taste.'),
    ];

    constructor(private httpClient:HttpClient) { }

    httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/json; charset=utf-8',
        'Authorization': 'Bearer ' + sessionStorage.getItem('authtoken')
      }),
      params : {}
    };

    getAllRecipeTypes() {
      return this.httpClient.get<RecipeType[]>(
        'http://localhost:8080/ezdish/recipetypes', this.httpOptions);
    }

    getAllRecipesByCategory(category: string) {
      return this.httpClient.get<Recipe[]>(
        'http://localhost:8080/ezdish/recipes/' + category, this.httpOptions)
    }

    getRecipeByCode(code: string) {
      let params = new HttpParams();
      params = params.append('code', code);
      this.httpOptions.params = params;

      return this.httpClient.get<Recipe[]>(
         'http://localhost:8080/ezdish/recipes/', this.httpOptions)
    }

    getAllUnits() {
      return this.uoms;
    }

    saveRecipe(recipe: Recipe) {
      return this.httpClient.post<Recipe[]>(
        'http://localhost:8080/ezdish/saverecipe/', recipe, this.httpOptions)
    }
}
