import { Ingredient } from "./Ingredient.model";
import { Preparation } from "./Preparation.model";

export class Recipe {
  code: string;
  name: string;
  recipeType: string;
  description: string;
  image: string;
  author: string;
  ingredients: Ingredient[];
  preparations: Preparation[];
  video: string;

  constructor(code: string,
              name: string,
              recipeType: string,
              description: string,
              image: string,
              author: string,
              ingredients: Ingredient[],
              preparations: Preparation[],
              video: string) {
    this.code = code;
    this.name = name;
    this.recipeType = recipeType;
    this.description = description;
    this.image = image;
    this.author = author;
    this.ingredients = ingredients;
    this.preparations = preparations;
    this.video = video;
  }
}
