export class Ingredient {
    name: string;
    quantity: number;
    uom: string;
    optional: boolean;
    tips: string;
  
    constructor(name: string, quanity: number, uom: string, optional: boolean, tips: string) {
      this.name = name;
      this.quantity = quanity;
      this.uom = uom;
      this.optional = optional;
      this.tips = tips;
    }
  }