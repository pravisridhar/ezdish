export class RecipeType {
  code: string;
  category: string;
  description: string;
  detail: string;
  image: string;

  constructor(code: string, category: string, desc: string, detail: string) {
    this.code = code;
    this.category = category;
    this.description = desc;
    this.detail = detail;
  }
}