export class Preparation {
    step: number;
    detail: string;
    optional: boolean;
    tips: string;

    constructor(step: number, detail: string, optional: boolean, tips: string) {
      this.step = step;
      this.detail = detail;
      this.optional = optional;
      this.tips = tips;
    }
}