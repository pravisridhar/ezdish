export class UOM {
  unit: string;
  description: string;
  remarks: string;

  constructor(unit: string, description: string, remarks: string) {
    this.unit = unit;
    this.description = description;
    this.remarks = remarks;
  }
}