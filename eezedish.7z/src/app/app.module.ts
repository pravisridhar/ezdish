import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AuthenticationService } from './service/auth/authentication.service';
import { HttpAuthInterceptorService } from './service/auth/http-auth-interceptor.service';

import { AboutModule } from './about/about.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { LayoutModule } from './layout/layout.module';
import { LoginModule } from './login/login.module';
import { RegisterModule } from './register/register.module';
import { AdminModule } from './admin/admin.module';
import { RecipesModule } from './modules/recipes/recipes.module';

import { RecipeService } from './service/recipe/recipe.service';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutModule,
    AboutModule,
    LoginModule,
    AdminModule,
    RegisterModule,
    DashboardModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule,
    RecipesModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    AuthenticationService,
    { provide:HTTP_INTERCEPTORS, useClass:HttpAuthInterceptorService, multi:true },
    RecipeService,
  ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  bootstrap: [AppComponent]
})
export class AppModule { }
