import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AuthenticationService } from '../service/auth/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  userName: string;
  password: string;
  invalidLogin: boolean = false;
  responseError = { status : '', message: ''};
  
  constructor(private router: Router,
    private loginservice: AuthenticationService,
    private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.spinner.show();
     setTimeout(() => {
      this.spinner.hide();
    }, 1000);
  }

  checkLogin() {
    setTimeout(() => { this.spinner.show(); }, 50);
    this.loginservice.authenticate(this.userName, this.password).subscribe(
      data => {
        this.router.navigate(['dashboard']);
        this.invalidLogin = false;
        setTimeout(() => { this.spinner.hide(); }, 50);
      },
      errorResponse => {
        this.invalidLogin = true;
        console.log(errorResponse);
        this.responseError.status = errorResponse.error.error;
        this.responseError.message = errorResponse.message;
        setTimeout(() => { this.spinner.hide(); }, 50);
      }
    );
  }
}
