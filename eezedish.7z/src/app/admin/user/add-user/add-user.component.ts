import { Component, OnInit } from '@angular/core';
import { UserService, User } from '../../../service/admin/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  user: User = new User("","","","","","",false,false);

  constructor(
    private userService: UserService
  ) { }

  ngOnInit() {
  }

  createUser(): void {
    this.userService.createUser(this.user)
        .subscribe( data => {
          alert("Employee created successfully..");
        });

  };

}