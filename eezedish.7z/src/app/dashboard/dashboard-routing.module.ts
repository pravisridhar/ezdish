import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicViewComponent } from '../layout/public-view/public-view.component';
import { DashboardComponent } from './dashboard.component';

const routes: Routes = [
  {
    path: 'dashboard',
    component: PublicViewComponent,
    children: [
      { path: '', component: DashboardComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
