import { Component, OnInit } from '@angular/core';

import { RecipeType } from '../../models/RecipeType.model';
import { RecipeService } from '../../service/recipe/recipe.service';
import { Subject } from 'rxjs';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-recipe-dashboard',
  templateUrl: './recipe-dashboard.component.html',
  styleUrls: ['./recipe-dashboard.component.css']
})
export class RecipeDashboardComponent implements OnInit {

  recipeTypes: RecipeType[] = [];
  loadingInProgress: boolean = false;
  responseError = { status : '', message: ''};

  constructor(private recipeService: RecipeService) { }

  ngOnInit(): void {
    this.loadingInProgress = true;
    this.recipeService.getAllRecipeTypes().subscribe(
      responseData => {
        for(let index = 0; index < responseData.length; index++) {
          this.recipeTypes.push(new RecipeType(
            responseData[index].code,
            responseData[index].category,
            responseData[index].description,
            responseData[index].detail
          ));
        }
        return this.recipeTypes.slice();
      },
      errorData => {
        this.responseError.status = errorData.error.error;
        this.responseError.message = errorData.message;
      }
    );
    this.loadingInProgress = false;
  }
}
