import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { RecipeDashboardComponent } from './recipe-dashboard/recipe-dashboard.component';

@NgModule({
  declarations: [
    DashboardComponent,
    RecipeDashboardComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    BrowserModule,
    NgbModule,
    NgxSpinnerModule
  ],
  providers: [
    NgxSpinnerService
  ]
})
export class DashboardModule { }
